<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Payments</title>
  <link href="validation_css/bootstrap.min.css" rel="stylesheet">
  <link href="validation_css/main.css" rel="stylesheet">

</head>
<body>
  <!-- Content -->
  <div class="container">
  <div class="row">
    		
  </div>
  </div>
  
  <div class="container">
  <div class="row">
  <div class="col-md-4 col-md-offset-4">
    <form role="form" action="">
      <div class="form-group">
        <label for="inputName">Name</label>
        <input class="form-control" id="inputName" name="name" type="text" placeholder="Enter name" required>
        <p class="help-block"></p>
      </div>
      <div class="form-group">
        <label for="inputPhone">Age</label>
        <input class="form-control" id="inputPhone" name="number" type="number" max="100" min="1" placeholder="Enter age" required>
        <p class="help-block"></p>
      </div>
      <div class="form-group">
        <label for="inputEmail">Email</label>
        <input class="form-control" id="inputEmail" name="email" type="email" placeholder="Enter email address" required>
        <p class="help-block"></p>
      </div>
      <div class="form-group">
        <label for="inputPassword">Password</label>
        <input class="form-control" id="inputPassword" name="password" type="password" minlength="6" placeholder="Enter password" required>
        <p class="help-block"></p>
      </div>
      <div class="form-group">
        <div class="checkbox">
          <label>
            <input name="agreed" type="checkbox" required> Agree to the <a href="javascript:void(0);">User Agreement</a>
          </label>
        </div>
        <p class="help-block"></p>
      </div>
      <div class="form-group">
        <button class="btn btn-primary" type="submit">Submit</button>
        <a class="btn btn-default" href="./">Reload</a>
      </div>
    </form>
	</div>
	
  </div>



  <!-- Scripts -->
  <script src="validation_js/jquery.min.js"></script>
  <script src="validation_js/bootstrap.min.js"></script>
  <script src="validation_js/validator.js"></script>
  <script src="validation_js/main.js"></script>
</body>
</html>
