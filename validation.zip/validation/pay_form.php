<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Payments</title>
  <link href="validation_css/bootstrap.min.css" rel="stylesheet">
  <link href="validation_css/main.css" rel="stylesheet">

</head>
<body>
<style type="text/css">
  .prinary h1{
    color: #f0ad4e;
  }
</style>

  
  <div class="container">
  

<div class="col-md-8 col-md-offset-2">
<div class="panel panel-primary">
    <div class="panel-heading">Payment Form</div>
    <div class="panel-body">
  <div class="row">
  <div class="col-md-8 col-md-offset-2 col-sm-12">
  <div class="row">
    <div class="col-md-4 col-md-offset-2">
    <img src="http://www.glitzresearch.com/front_images/logo.png" alt="" class="image image-responsive">
    </div>
  
  <div class="col-md-4 ">
    <p class="pull-right"><?php echo $_SERVER['REMOTE_ADDR']?></p>  
  </div>

  </div>
  <hr>
    <form role="form" action="confirmation.php" method="post">
    <div class="row">
    <div class="col-md-6">
      <div class="form-group">
                  <label for="inputName">Name</label>
                  <input class="form-control" id="inputName" name="name" type="text" placeholder="Enter name" required>
                  <p class="help-block"></p>
                </div>
    </div>
    <div class="col-md-6">
    
                 <div class="form-group">
                  <label for="inputEmail">Email</label>
                  <input class="form-control" id="inputEmail" name="email" type="email" placeholder="Enter email address" required>
                  <p class="help-block"></p>
                </div>
    </div>        
    </div>
      <hr>

     <div class="row">
    <div class="col-md-6">
              <div class="form-group">
              <label for="inputName">City</label>
              <input class="form-control" id="inputName" name="City" type="text" placeholder="City" required>
              <p class="help-block"></p>
            </div>
</div>
<div class="col-md-6">
      <div class="form-group">
        <label for="inputPhone">Mobile</label>
        <input class="form-control" id="inputPhone" name="mobile" type="number" placeholder="Mobile" required>
        <p class="help-block"></p>
      </div>
  </div>
</div>
  <hr>
<div class="row">
    <div class="col-md-6">
     <div class="form-group">
        <label for="inputName">Service</label>
        <input class="form-control" id="inputName" name="productinfo" type="text" placeholder="Service" required>
        <p class="help-block"></p>
      </div>
        </div>
          <div class="col-md-6">
       <div class="form-group">
        <label for="inputPhone">Total Amount</label>
        <input class="form-control" id="inputPhone" name="amount" type="number" placeholder="Amount" required>
        <p class="help-block"></p>
      </div>
</div>
</div>
  <hr>
<div class="row">
    <div class="col-md-6 col-md-offset-2">
      <div class="form-group">
        <div class="checkbox">
          <label>
            <input name="agreed" type="checkbox" required> Agree to the <a href="javascript:void(0);">User Agreement</a>
          </label>
        </div>
        <p class="help-block"></p>
      </div>
    </div>
    </div>
    <div class="row">
    <div class="col-md-6 col-md-offset-2">
      <div class="form-group">
        <button class="btn btn-primary btn-lg btn-block" type="submit">Submit</button>
        </div>
    </div>
    
</div>
    </form>
	</div>

</div>
  </div>
	</div>
  </div>



  <!-- Scripts -->
  <script src="validation_js/jquery.min.js"></script>
  <script src="validation_js/bootstrap.min.js"></script>
  <script src="validation_js/validator.js"></script>
  <script src="validation_js/main.js"></script>
</body>
</html>
