<style type="text/css">
	.error{
		color: red;
	}

</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

<input type="text" name="old" id="old">
<input type="text" id="newpass" style="display:none">
<input type="text" id="newconfirm" style="display:none">
<button id="submit" style="display:none">Confirm</button>

<div class="result"></div>
<div class="r" style="display:none">123</div>
<script src="../c/change.js"></script>