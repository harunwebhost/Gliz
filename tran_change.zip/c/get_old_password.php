<?php 
	require_once("../db_function.php");
	$old_password=sql_injection($_POST['old_password']);
	$logged_username="ajaz@gmail.com";
if(isset($old_password) && empty($_POST['new_pass']) && empty($_POST['confirm_pass'])){
	echo $check_old_pass="SELECT * FROM crm_users WHERE user_password='$old_password' AND user_email='$logged_username'";
		if($result=execute_sql_query($check_old_pass)){
		$count=sql_fetch_num_rows($result);
		if($count>0){
echo $html = <<<SHOW
<script>
$("#newconfirm").show();
$("#newpass").show();
</script>
SHOW;
		}else{
				echo  "old password is wrong";
			}
}
}else{
	echo $new_pass=sql_injection($_POST['new_pass']);
	echo $confirm_pass=sql_injection($_POST['confirm_pass']);
	if($new_pass==$confirm_pass){
		$update_pass="UPDATE crm_users SET user_password='$new_pass' WHERE user_email='ajaz@gmail.com' LIMIT 1";
		if(execute_sql_query($update_pass)){
			echo "Password is updated";
		}
	}
	
}


?>